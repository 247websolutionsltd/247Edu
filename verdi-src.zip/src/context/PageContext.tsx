import { createContext, ReactNode, useContext, useState } from "react";

/* -------------------------------------------------------------------------- */
/* Theme                                                                       */
/* -------------------------------------------------------------------------- */

export type ThemeMode = "light" | "dark";

type ThemeContextType = {
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  toggleThemeMode: () => void;
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function AppThemeProvider({
  children,
  initialTheme = "dark",
}: {
  children: ReactNode;
  initialTheme?: ThemeMode;
}) {
  const [themeMode, setThemeMode] = useState<ThemeMode>(initialTheme);
  const toggleThemeMode = () => setThemeMode((c) => (c === "light" ? "dark" : "light"));

  return (
    <ThemeContext.Provider value={{ themeMode, setThemeMode, toggleThemeMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useAppTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useAppTheme must be used inside an AppThemeProvider");
  return context;
}

/* -------------------------------------------------------------------------- */
/* Auth / profile                                                              */
/* -------------------------------------------------------------------------- */

type LogInForm = { email: string; password: string };
type RegisterForm = {
  email: string;
  password: string;
  confirm: string;
  name: string;
  phone: string;
};

export type Owner = {
  name: string;
  tier: string;
  phone: string;
  email: string;
  referralCode: string;
};

type AuthContextType = {
  loading: boolean;
  logInForm: LogInForm;
  updateLogInField: (field: keyof LogInForm, value: string) => void;
  registerForm: RegisterForm;
  updateRegisterField: (field: keyof RegisterForm, value: string) => void;
  owner: Owner;
  updateOwner: (patch: Partial<Owner>) => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading] = useState(false);
  const [logInForm, setLogInForm] = useState<LogInForm>({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState<RegisterForm>({
    email: "",
    password: "",
    confirm: "",
    name: "",
    phone: "",
  });
  const [owner, setOwner] = useState<Owner>({
    name: "Ken Nwaeze",
    tier: "Tier 2 · Verified",
    phone: "0803 555 0148",
    email: "ken@example.com",
    referralCode: "KEN2400",
  });

  return (
    <AuthContext.Provider
      value={{
        loading,
        logInForm,
        updateLogInField: (f, v) => setLogInForm((p) => ({ ...p, [f]: v })),
        registerForm,
        updateRegisterField: (f, v) => setRegisterForm((p) => ({ ...p, [f]: v })),
        owner,
        updateOwner: (patch) => setOwner((p) => ({ ...p, ...patch })),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside an AuthProvider");
  return context;
}

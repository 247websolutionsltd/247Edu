import { Logo } from '@/components/brand';
import { ThemedText } from '@/components/themed-text';
import { HeroDecor } from '@/components/ui';
import { Brand } from '@/constants/brand';
import { Colors } from '@/constants/theme';
import { goReplace } from '@/lib/nav';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect } from 'react';
import { StatusBar, View } from 'react-native';

/** Branded splash. Decides between onboarding (first launch) and sign-in. */
export default function Splash() {
  useEffect(() => {
    let mounted = true;
    const start = Date.now();

    const decide = async () => {
      let target = '/onboard';
      try {
        const done = await AsyncStorage.getItem('onboarded');
        if (done === 'true') target = '/auth/logIn';
      } catch (e) {
        console.error('Unable to read onboarding status', e);
      }
      // keep the splash visible just long enough to feel intentional
      const wait = Math.max(0, 900 - (Date.now() - start));
      setTimeout(() => mounted && goReplace(target), wait);
    };

    decide();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.hero, alignItems: 'center', justifyContent: 'center' }}>
      <StatusBar barStyle="light-content" />
      <HeroDecor />
      <Logo size={64} light />
      <ThemedText style={{ color: Colors.heroMuted, marginTop: 14, letterSpacing: 2, fontWeight: '600' }}>
        {Brand.tagline.toUpperCase()}
      </ThemedText>
    </View>
  );
}

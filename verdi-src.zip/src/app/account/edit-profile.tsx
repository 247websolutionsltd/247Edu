import Avatar from "@/components/avatar";
import Button from "@/components/button";
import Container from "@/components/custom-container";
import Input from "@/components/custom-input";
import Header from "@/components/header";
import { Spacing } from "@/constants/theme";
import { useAuth } from "@/context/PageContext";
import { router } from "expo-router";
import { useState } from "react";
import { View } from "react-native";

export default function EditProfile() {
  const { owner, updateOwner } = useAuth();
  const [name, setName] = useState(owner.name);
  const [email, setEmail] = useState(owner.email);
  const [phone, setPhone] = useState(owner.phone);
  const [error, setError] = useState<string | null>(null);

  const save = () => {
    if (!name.trim()) return setError("Your name can't be empty.");
    updateOwner({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    router.back();
  };

  return (
    <Container edges={["top", "bottom"]}>
      <Header title="Edit profile" />
      <View style={{ paddingHorizontal: Spacing.three }}>
        <View style={{ alignItems: "center", marginVertical: Spacing.three }}>
          <Avatar name={name || owner.name} size={92} />
        </View>
        <Input label="Full name" icon="person-outline" value={name} onChangeText={setName} error={error} />
        <Input label="Email" icon="mail-outline" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
        <Input label="Phone number" icon="call-outline" value={phone} onChangeText={setPhone} number />
        <Button title="Save changes" onPress={save} style={{ marginTop: Spacing.four }} />
      </View>
    </Container>
  );
}
